#include<stdio.h>
int main()
{
    char a,b,c,d,e,f,g,h,i,j,k;
    scanf("%c-%c%c%c-%c%c%c-%c%c%c%c",&a,&b,&c,&d,&e,&f,&g,&h,&i,&j,&k);
    if(a<65 || a>90) {printf("%c-",a);}
    else if(a=='A'||a=='B'||a=='C') {printf("2-");}
    else if (a=='D'||a=='E'||a=='F') {printf("3-");}
    else if (a=='G'||a=='H'||a=='I') {printf("4-");}
    else if (a=='J'||a=='K'||a=='L') {printf("5-");}
    else if (a=='M'||a=='N'||a=='O') {printf("6-");}
    else if (a=='P'||a=='Q'||a=='R'||a=='S') {printf("7-");}
    else if (a=='T'||a=='U'||a=='V') {printf("8-");}
    else if (a=='W'||a=='X'||a=='Y'||a=='Z') {printf("9-");}

    if(b<65 || b>90) {printf("%c",b);}
    else if(b=='A'||b=='B'||b=='C') {printf("2");}
    else if (b=='D'||b=='E'||b=='F') {printf("3");}
    else if (b=='G'||b=='H'||b=='I') {printf("4");}
    else if (b=='J'||b=='K'||b=='L') {printf("5");}
    else if (b=='M'||b=='N'||b=='O') {printf("6");}
    else if (b=='P'||b=='Q'||b=='R'||b=='S') {printf("7");}
    else if (b=='T'||b=='U'||b=='V') {printf("8");}
    else if (b=='W'||b=='X'||b=='Y'||b=='Z') {printf("9");}

     if(c<65 || c>90) {printf("%c",c);}
    else if (c=='A'||c=='B'||c=='C') {printf("2");}
    else if (c=='D'||c=='E'||c=='F') {printf("3");}
    else if (c=='G'||c=='H'||c=='I') {printf("4");}
    else if (c=='J'||c=='K'||c=='L') {printf("5");}
    else if (c=='M'||c=='N'||c=='O') {printf("6");}
    else if (c=='P'||c=='Q'||c=='R'||c=='S') {printf("7");}
    else if (c=='T'||c=='U'||c=='V') {printf("8");}
    else if (c=='W'||c=='X'||c=='Y'||c=='Z') {printf("9");}

     if(d<65 || d>90) {printf("%c-",d);}
    else if(d=='A'||d=='B'||d=='C') {printf("2-");}
    else if (d=='D'||d=='E'||d=='F') {printf("3-");}
    else if (d=='G'||d=='H'||d=='I') {printf("4-");}
    else if (d=='J'||d=='K'||d=='L') {printf("5-");}
    else if (d=='M'||d=='N'||d=='O') {printf("6-");}
    else if (d=='P'||d=='Q'||d=='R'||d=='S') {printf("7-");}
    else if (d=='T'||d=='U'||d=='V') {printf("8-");}
    else if (d=='W'||d=='X'||d=='Y'||d=='Z') {printf("9-");}

     if(e<65 || e>90) {printf("%c",e);}
    else if(e=='A'||e=='B'||e=='C') {printf("2");}
    else if (e=='D'||e=='E'||e=='F') {printf("3");}
    else if (e=='G'||e=='H'||e=='I') {printf("4");}
    else if (e=='J'||e=='K'||e=='L') {printf("5");}
    else if (e=='M'||e=='N'||e=='O') {printf("6");}
    else if (e=='P'||e=='Q'||e=='R'||e=='S') {printf("7");}
    else if (e=='T'||e=='U'||e=='V') {printf("8");}
    else if (e=='W'||e=='X'||e=='Y'||e=='Z') {printf("9");}

     if(f<65 || f>90) {printf("%c",f);}
    else if(f=='A'||f=='B'||f=='C') {printf("2");}
    else if (f=='D'||f=='E'||f=='F') {printf("3");}
    else if (f=='G'||f=='H'||f=='I') {printf("4");}
    else if (f=='J'||f=='K'||f=='L') {printf("5");}
    else if (f=='M'||f=='N'||f=='O') {printf("6");}
    else if (f=='P'||f=='Q'||f=='R'||f=='S') {printf("7");}
    else if (f=='T'||f=='U'||f=='V') {printf("8");}
    else if (f=='W'||f=='X'||f=='Y'||f=='Z') {printf("9");}

     if(g<65 || g>90) {printf("%c-",g);}
    else if(g=='A'||g=='B'||g=='C') {printf("2-");}
    else if (g=='D'||g=='E'||g=='F') {printf("3-");}
    else if (g=='G'||g=='H'||g=='I') {printf("4-");}
    else if (g=='J'||g=='K'||g=='L') {printf("5-");}
    else if (g=='M'||g=='N'||g=='O') {printf("6-");}
    else if (g=='P'||g=='Q'||g=='R'||g=='S') {printf("7-");}
    else if (g=='T'||g=='U'||g=='V') {printf("8-");}
    else if (g=='W'||g=='X'||g=='Y'||g=='Z') {printf("9-");}

     if(h<65 || h>90) {printf("%c",h);}
    else if(h=='A'||h=='B'||h=='C') {printf("2");}
    else if (h=='D'||h=='E'||h=='F') {printf("3");}
    else if (h=='G'||h=='H'||h=='I') {printf("4");}
    else if (h=='J'||h=='K'||h=='L') {printf("5");}
    else if (h=='M'||h=='N'||h=='O') {printf("6");}
    else if (h=='P'||h=='Q'||h=='R'||h=='S') {printf("7");}
    else if (h=='T'||h=='U'||h=='V') {printf("8");}
    else if (h=='W'||h=='X'||h=='Y'||h=='Z') {printf("9");}

     if(i<65 || i>90) {printf("%c",i);}
    else if(i=='A'||i=='B'||i=='C') {printf("2");}
    else if (i=='D'||i=='E'||i=='F') {printf("3");}
    else if (i=='G'||i=='H'||i=='I') {printf("4");}
    else if (i=='J'||i=='K'||i=='L') {printf("5");}
    else if (i=='M'||i=='N'||i=='O') {printf("6");}
    else if (i=='P'||i=='Q'||i=='R'||i=='S') {printf("7");}
    else if (i=='T'||i=='U'||i=='V') {printf("8");}
    else if (i=='W'||i=='X'||i=='Y'||i=='Z') {printf("9");}

     if(j<65 || j>90) {printf("%c",j);}
    else if(j=='A'||j=='B'||j=='C') {printf("2");}
    else if (j=='D'||j=='E'||j=='F') {printf("3");}
    else if (j=='G'||j=='H'||j=='I') {printf("4");}
    else if (j=='J'||j=='K'||j=='L') {printf("5");}
    else if (j=='M'||j=='N'||j=='O') {printf("6");}
    else if (j=='P'||j=='Q'||j=='R'||j=='S') {printf("7");}
    else if (j=='T'||j=='U'||j=='V') {printf("8");}
    else if (j=='W'||j=='X'||j=='Y'||j=='Z') {printf("9");}

     if(k<65 || k>90) {printf("%c",k);}
    else if(k=='A'||k=='B'||k=='C') {printf("2");}
    else if (k=='D'||k=='E'||k=='F') {printf("3");}
    else if (k=='G'||k=='H'||k=='I') {printf("4");}
    else if (k=='J'||k=='K'||k=='L') {printf("5");}
    else if (k=='M'||k=='N'||k=='O') {printf("6");}
    else if (k=='P'||k=='Q'||k=='R'||k=='S') {printf("7");}
    else if (k=='T'||k=='U'||k=='V') {printf("8");}
    else if (k=='W'||k=='X'||k=='Y'||k=='Z') {printf("9");}



    return 0;
}
