#include<stdio.h>
int main()
{
    int item;
    printf("Enter item number:");
    scanf("%d",&item);

    float price;
    printf("Enter Unit Price:");
    scanf("%f",&price);

    int mm,dd,yyy;

    printf("Enter a date (mm/dd/yyy):");
    scanf("%d/%d/%d",&mm,&dd,&yyy);

    printf("Item Price   Date       Unit Purchase\n$%.2f%9d/%d/%d%14d",price,mm,dd,yyy,item);


    return 0;
}
