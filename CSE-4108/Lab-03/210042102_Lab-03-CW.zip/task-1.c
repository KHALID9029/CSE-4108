#include<stdio.h>
int main()
{
    int mm,dd,yyy;
    printf("Enter a date (mm/dd/yyy):");
    scanf("%d/%d/%d",&mm,&dd,&yyy);
    printf("You entered the date %d%.2d%d",yyy,mm,dd);





    return 0;
}
