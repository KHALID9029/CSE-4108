#include<stdio.h>
int main()
{
    int a,b,c,d;


    printf("Enter two fractions separated by a plus sign:");
    scanf("%d/%d+%d/%d",&a,&b,&c,&d);

    int y=b*d;
    int x=(a*(y/b))+ (c*(y/d));
    printf("%d/%d",x,y);







    return 0;
}
