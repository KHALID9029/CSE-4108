#include<stdio.h>
int main ()
{
    int a;
    printf("Enter a five-digit integer:");
    scanf("%d",&a);

    int sum1=a/10000;
    int c=a%10000;
    int sum2=c/1000;
    int d= c%1000;
    int sum3= d/100;
    int e=d%100;
    int sum4=e/10;
    int sum5=e%10;
    int x=sum1+sum2+sum3+sum4+sum5;
    printf ("%d",x);

return 0;
}
