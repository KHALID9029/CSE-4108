#include<stdio.h>
int main()
{
    int prefix,ide,code,number,digit;
    printf("Enter ISBN:");
    scanf("%d-%d-%d-%d-%d",&prefix,&ide,&code,&number,&digit);

    printf("GSI prefix: %d\n",prefix);
    printf("Group Identifier: %d\n",ide);
    printf("Publisher code: %d\n",code);
    printf("Item Number: %d\n",number);
    printf("check digit: %d\n",digit);


    return 0;
}
