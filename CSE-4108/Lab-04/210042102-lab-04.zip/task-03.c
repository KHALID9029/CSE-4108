#include<stdio.h>
int main()
{
    printf("Enter a three-digit number (x-x-x): ");
    int a,b,c;
    scanf("%d-%d-%d",&a,&b,&c);

    printf("The reversal is: %d%d%d",c,b,a);





    return 0;
}
