#include<stdio.h>
int main()
{
    int ara[4],a,b;
    int i,j;
    for(i=0;i<4;i++)
    {
        scanf("%d",&ara[i]);
    }

    for(i=0;i<4;i++)
    {
        for(j=i+1;j<4;j++)
        {
            if(ara[i]>ara[j])
            {
                int temp=ara[i];
                ara[i]=ara[j];
                ara[j]=temp;
            }
        }

    }
    if (ara[3]==(ara[0]+ara[1])||ara[2]==(ara[0]+ara[1])) {printf("SEGMENT\n");}
    if (ara[3]>(ara[0]+ara[1])||ara[2]>(ara[0]+ara[1])) {printf("TRIANGLE\n");}
    else {printf("IMPOSSIBLE");}




    return 0;
}
