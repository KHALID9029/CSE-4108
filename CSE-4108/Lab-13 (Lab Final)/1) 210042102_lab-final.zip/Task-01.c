#include<stdio.h>
#include<string.h>
int main()
{
    int width[26];
    int i;
    for(i=0;i<26;i++)
    {
        scanf("%d",&width[i]);
    }
    getchar();
    char s[100];
    gets(s);
    int l=strlen(s);

    int j,line=1,sum=0,x=0,x1=l;
    for(j=0;j<l;j++)
    {
        int v=s[j]-97;
        sum+=width[v];x++;
        if(sum==100) {line++;sum=0;x1=x1-(l-x);x=0;}
    }
    if(x1<0) {x1=x1*(-1);}
    int k=0,z=l-1,y,ans=0;
    while(k!=x1)
    {
        int y=s[z]-97;
        ans+=width[y];
        k++;
        z--;
    }

    printf("%d %d\n",line,ans);




    return 0;
}
//10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10
//abcdefghijklmnopqrstuvwxyz
