#include<stdio.h>
int main ()
{
    printf("Enter the radius of the sphere:");
    float r;
    scanf ("%f",&r);
    float v=(4.0f/3.0f * 3.14159*r*r*r);
    printf("%f",v);

return 0;
}



