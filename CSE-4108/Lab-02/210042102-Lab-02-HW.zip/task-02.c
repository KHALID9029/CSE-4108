#include<stdio.h>
int main()
{
    float Pi=3.14159;
    int r=10;
    float v=(4.0f/3.0f * Pi*r*r*r);
    printf("%f",v);

return 0;
}
