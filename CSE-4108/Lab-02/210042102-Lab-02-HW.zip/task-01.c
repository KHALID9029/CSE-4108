#include<stdio.h>
int main()
{

    char star='*';
    printf("%8c\n",star);
    printf("%7c\n",star);
    printf("%6c\n",star);
    printf("%c",star);
    printf("%4c\n",star);
    printf("%2c",star);
    printf("%2c\n",star);
    printf("%3c",star);
return 0;
}
