#include<stdio.h>
int main()
{
    printf("Enter the value of x:");
    int x;
    scanf("%d",&x);
    int y=(((((3*x+2)*x-5)*x-1)*x+7)*x-6);
    printf("%d",y);


    return 0;
}
